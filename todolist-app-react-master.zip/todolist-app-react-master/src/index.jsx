import React from "react";
import ReactDOM from "react-dom";
import ToDoListApp from "./App/ToDoApp.jsx";

ReactDOM.render(<ToDoListApp />, document.getElementById("root"));